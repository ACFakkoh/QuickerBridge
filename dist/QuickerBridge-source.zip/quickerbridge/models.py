"""Validated, unit-explicit inputs shared by analysis and exports."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class InputModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


BAR_DIAMETERS = {"10M": 11.3, "15M": 16.0, "20M": 19.5}  # mm


class CompositeSlab(BaseModel):
    """Concrete deck acting with a steel girder.

    Section properties, stresses and resistance. It changes the beam stiffness
    only through ``Section.inertia_source`` (3n, 1n or I′, v0.9.99).
    Lengths in mm, f'c and Fy in MPa, concrete unit weight in kN/m³.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    slab_thickness: float = Field(default=225, gt=0, le=2000)  # tc (v0.9.8: 225)
    haunch: float = Field(default=50, ge=0, le=1000)  # concrete haunch
    effective_width: float = Field(default=3110, gt=0, le=20000)  # be
    fc: float = Field(default=35, gt=0, le=150)  # f'c
    unit_weight: float = Field(default=24.0, gt=10, le=40)  # γc, kN/m³
    bar_top: Literal["10M", "15M", "20M"] = "15M"
    spacing_top: float = Field(default=300, gt=10, le=2000)
    bar_bottom: Literal["10M", "15M", "20M"] = "15M"
    spacing_bottom: float = Field(default=300, gt=10, le=2000)
    cover_top: float = Field(default=60, ge=0, le=500)
    cover_bottom: float = Field(default=35, ge=0, le=500)
    fy: float = Field(default=345, gt=0, le=1000)  # girder steel Fy
    frqr: float = Field(default=0.85, gt=0, le=1)  # effective properties
    # S3: distance below the elastic neutral axis (positive downward), mm.
    y3: float = Field(default=500, gt=0, le=15000)
    # v0.9.5: y of S3 per configuration, each below its own ENA; None = y3.
    y_steel: float | None = Field(default=None, gt=0, le=15000)
    y_3n: float | None = Field(default=None, gt=0, le=15000)
    y_1n: float | None = Field(default=None, gt=0, le=15000)
    y_neg: float | None = Field(default=None, gt=0, le=15000)  # I' (M−)
    # Region shown in the section properties window: positive moment (steel,
    # 3n, 1n) or negative moment (steel and I' = steel + bars in tension).
    region: Literal["positive", "negative"] = "positive"

    @model_validator(mode="after")
    def bars_in_slab(self):
        # v0.9.6: both layers inside the concrete, top above bottom, no
        # overlap; the field limits alone do not check their compatibility.
        dt, db = BAR_DIAMETERS[self.bar_top], BAR_DIAMETERS[self.bar_bottom]
        top = self.slab_thickness - self.cover_top - dt / 2
        bottom = self.cover_bottom + db / 2
        if (
            self.cover_top + dt > self.slab_thickness
            or self.cover_bottom + db > self.slab_thickness
            or top - dt / 2 < bottom + db / 2
            or min(self.spacing_top, self.spacing_bottom) < max(dt, db)
        ):
            raise ValueError("composite.bars")
        return self

    def y_of(self, config: str) -> float:
        value = getattr(self, f"y_{config}")
        return self.y3 if value is None else value


NEBT_TYPES = ("NEBT1000", "NEBT1200", "NEBT1400", "NEBT1600", "NEBT1800")
NEBT_DEFAULT_E = 28.0  # GPa, prestressed concrete; editable per section


def concrete_modulus(fc: float, unit_weight: float) -> float:
    """Ec in MPa: (3300 √f'c + 6900) (γc / 2300)^1.5 with the
    density γc in kg/m³ (unit weight kN/m³ × 1000 / 9.81). Same expression as
    the slab of the section properties window and the creep strain."""
    density = unit_weight * 1000 / 9.81
    return (3300 * fc**0.5 + 6900) * (density / 2300) ** 1.5


class Section(InputModel):
    name: str = Field(default="S1", max_length=60)
    # girder: steel I from plates; ei: direct stiffness; nebt: standard
    # precast prestressed NEBT girder with tabulated properties.
    kind: Literal["girder", "ei", "nebt"] = "girder"
    nebt: Literal[NEBT_TYPES] = "NEBT1400"
    EI: float = Field(default=20_000_000, gt=0, le=1e15)  # kN m², direct stiffness
    E: float = Field(default=200, gt=0, le=1000)  # GPa
    inertia_modifier: float = Field(default=1, gt=0, le=1000)
    depth: float = Field(default=1200, gt=0, le=15000)  # mm, overall depth
    top_width: float = Field(default=350, gt=0, le=20000)
    top_thickness: float = Field(default=25, gt=0, le=2000)
    web_thickness: float = Field(default=14, gt=0, le=2000)
    bottom_width: float = Field(default=600, gt=0, le=20000)
    bottom_thickness: float = Field(default=50, gt=0, le=2000)
    composite: CompositeSlab | None = None  # section properties module only
    # v0.9.8: how the stiffness of a direct-EI or NEBT section is given.
    #   "EI": EI directly (direct-EI sections, kN·m²);
    #   "concrete": E from f'c and γc (S6-25 8.4.1.7) times I;
    #   "modulus": E entered (GPa, shown in MPa) times I.
    # NEBT sections use "concrete" (new) or "modulus" (projects before 0.9.8).
    stiffness_input: Literal["EI", "concrete", "modulus"] = "EI"
    I_direct: float = Field(default=0.25, gt=0, le=1e6)  # m⁴, direct-EI section
    fc: float = Field(default=35, gt=0, le=150)  # MPa (NEBT: 50)
    unit_weight: float = Field(default=24, gt=10, le=40)  # kN/m³ (NEBT: 24.5)
    # Inertia used by the analysis for a steel or NEBT girder (v0.9.99):
    # "steel": the girder alone (M+ or M−); "3n", "1n": composite section
    # (M+); "negative": cracked I′ = steel + bars (M−). The modifier M is
    # set automatically to I(config) / I(girder alone), so the composite
    # inertia is applied exactly once; without a slab, the girder alone.
    # "manual" (I girder × M as entered) only survives in projects saved
    # before v0.9.99 with M ≠ 1; the interface no longer offers it.
    inertia_source: Literal["steel", "3n", "1n", "negative", "manual"] = "steel"

    @model_validator(mode="before")
    @classmethod
    def concrete_defaults(cls, data):
        if not isinstance(data, dict):
            return data
        data = dict(data)
        # v0.9.99: the entered multiplier is gone. An older section (no
        # source, or "manual") with M = 1 is the girder alone; with M ≠ 1 it
        # keeps its multiplier ("manual", legacy) until another choice.
        if data.get("inertia_source", "manual") == "manual":
            legacy = float(data.get("inertia_modifier", 1) or 1) != 1
            data["inertia_source"] = "manual" if legacy else "steel"
        if data.get("kind") == "nebt":
            # Projects before 0.9.8 entered E for NEBT girders: keep it.
            data.setdefault("stiffness_input", "modulus" if "E" in data else "concrete")
            data.setdefault("fc", 50)
            data.setdefault("unit_weight", 24.5)
            data.setdefault("E", NEBT_DEFAULT_E)
        return data

    @model_validator(mode="after")
    def derived_stiffness(self):
        # E (GPa) and EI (kN·m²) always hold the values used by the analysis.
        mode = self.stiffness_input
        if self.kind == "nebt" and mode == "EI":
            mode = self.stiffness_input = "concrete"
        if self.kind in ("ei", "nebt") and mode == "concrete":
            self.E = round(concrete_modulus(self.fc, self.unit_weight) / 1000, 6)
        if self.kind == "ei" and mode in ("concrete", "modulus"):
            self.EI = self.E * 1e6 * self.I_direct
        slab = self.composite is not None and self.composite.enabled
        if self.kind in ("girder", "nebt") and (
            self.inertia_source == "steel"
            or (self.inertia_source != "manual" and not slab)
        ):
            self.inertia_modifier = 1.0
        elif (
            self.inertia_source != "manual" and self.kind in ("girder", "nebt") and slab
        ):
            from .section_props import section_properties

            props = section_properties(self)
            comp = props["composite"]
            ratio = (
                comp["negative"]["ratio"]
                if self.inertia_source == "negative"
                else comp[self.inertia_source]["I"] / props["steel"]["Ix"]
            )
            self.inertia_modifier = round(float(ratio), 6)
        return self

    @model_validator(mode="after")
    def geometry(self):
        if self.kind in ("ei", "nebt"):
            return self
        if self.depth <= self.top_thickness + self.bottom_thickness:
            raise ValueError("geometry.depth")
        if self.web_thickness > min(self.top_width, self.bottom_width):
            raise ValueError("geometry.web")
        return self


class Zone(InputModel):
    end: float = Field(gt=0, le=1)  # fraction of span; starts at previous end
    section: int = Field(ge=0)
    end_section: int | None = Field(default=None, ge=0)
    profile: Literal["constant", "linear", "parabolic"] = "constant"
    # Which section supplies plates, E and inertia modifier in a taper. Only
    # the overall depth is interpolated. "start" is the v0.4 behaviour; "end"
    # and "deep" make a haunch invariant when start/end sections are swapped.
    plates: Literal["start", "end", "deep"] = "start"


def plate_source(zone, a, b):
    """Section providing plates/E/modifier for a zone between sections a, b."""
    if zone.plates == "end":
        return b
    if zone.plates == "deep" and b.depth > a.depth:
        return b
    return a


class Span(InputModel):
    length: float = Field(default=34.8, ge=0.5, le=200)
    section: int = Field(default=0, ge=0)
    zones: list[Zone] = Field(default_factory=list, max_length=12)
    # Simply supported (isostatic) span: moment releases at both ends, so no
    # continuity with the neighbouring spans.
    simple: bool = False


class SelfWeight(InputModel):
    """Girder self-weight added to the permanent loads (steel and NEBT only).

    ``*_increase`` are percentage allowances on the nominal girder weight
    (stiffeners, diaphragms, connections...); ``factor`` is a load factor like
    the one of the other permanent loads.
    """

    apply: bool = True
    steel_increase: float = Field(default=15, ge=0, le=200)  # %
    nebt_increase: float = Field(default=10, ge=0, le=200)  # %
    factor: float = Field(default=1, ge=0, le=1000)


class DeadLoad(InputModel):
    name: str = Field(default="Permanent load", max_length=80)
    w: float = Field(default=10, ge=0, le=10000)
    factor: float = Field(default=1, ge=0, le=1000)
    span: int = Field(default=-1, ge=-1)  # -1 = all spans
    start: float = Field(default=0, ge=0, lt=1)
    end: float = Field(default=1, gt=0, le=1)
    # Stress diagrams (v0.9.6): section carrying this load. "steel": girder
    # alone (e.g. slab weight, unshored construction); "3n": long-term
    # composite (superimposed dead loads). The girder self-weight is always
    # carried by the girder alone.
    stage: Literal["steel", "3n"] = "3n"

    @model_validator(mode="after")
    def extent(self):
        if self.end <= self.start:
            raise ValueError("load.extent")
        return self


class LiveLoad(InputModel):
    vehicle: Literal[
        "CL625",
        "CL750QC",
        "HL93Truck",
        "HL93Tandem",
        "Cooper",
        "Maintenance",
        "custom",
    ] = "CL750QC"
    weights: list[float] = Field(
        default_factory=lambda: [50, 125, 125, 175, 150], min_length=1, max_length=7
    )
    spacings: list[float] = Field(
        default_factory=lambda: [3.6, 1.2, 6.6, 6.6], max_length=6
    )
    case: Literal["governing", "truck", "lane"] = "governing"
    # v0.9.96: live-load source. "pedestrian" replaces the vehicle by the
    # S6 pedestrian load (Model.pedestrian); the two are never combined.
    source: Literal["vehicle", "pedestrian"] = "vehicle"
    # v0.9.96: extent of the lane-load UDL (S6 C3.8.4.1: applied only where
    # it increases the load effect). "spans": the spans whose unit-UDL effect
    # has the sign sought, per response; "influence": the parts of the
    # influence line of that sign (partial spans); "full": whole bridge
    # (method of v0.9.95 and earlier).
    lane_extent: Literal["spans", "influence", "full"] = "spans"
    lane_fraction: Literal[0.63, 0.8] = 0.8
    # CL-750-QC only: MTQ Info-structures A2023-05 chooses 63 % or 80 % of the
    # axles per response; when on, lane_fraction is ignored.
    mtq_auto: bool = True
    lane_w: float = Field(default=9, ge=0, le=1000)  # custom vehicle only
    cooper_e: float = Field(default=80, ge=10, le=200)  # AREA / AREMA Cooper E
    # v0.9.97: S6-25 Section 14 evaluation level (Figure 14.1). "design":
    # the design truck and lane load of Section 3. Levels 1, 2, 3: CL1-W
    # (5 axles), CL2-W (axles 1-4), CL3-W (axles 1-3), axles 0.08, 0.2, 0.2,
    # 0.28, 0.24 W; lane load 80 % of those axles plus q of the road class
    # (14.9.1.7). v0.9.98: CL-625 only (W = 625 kN), the CL-750-QC is not an
    # evaluation vehicle; road classes C and D (same q) are one option.
    evaluation: Literal["design", "1", "2", "3"] = "design"
    road_class: Literal["A", "B", "CD"] = "A"
    factor: float = Field(default=1, ge=0, le=1000)
    axle_factor: float = Field(default=1, ge=0, le=1000)
    dynamic: bool = True
    two_trucks: bool = False  # HL-93 supplementary 90% negative-moment/pier case
    # v0.9.7: the vehicle always travels in both directions. Older projects
    # may still hold "forward"/"reverse"; they are read as "both".
    direction: Literal["both", "forward", "reverse"] = "both"

    @model_validator(mode="before")
    @classmethod
    def road_class_cd(cls, data):
        # v0.9.98: classes C and D merged; v0.9.97 files may hold either.
        if isinstance(data, dict) and data.get("road_class") in ("C", "D"):
            data = dict(data)
            data["road_class"] = "CD"
        return data

    @model_validator(mode="after")
    def both_directions(self):
        self.direction = "both"
        return self

    @model_validator(mode="after")
    def evaluation_cl625_only(self):
        # v0.9.98: Section 14 evaluation levels for the CL-625 only.
        if self.vehicle != "CL625":
            self.evaluation = "design"
        return self

    @model_validator(mode="after")
    def axles(self):
        if len(self.spacings) != len(self.weights) - 1:
            raise ValueError("vehicle.spacing_count")
        if any(not 0 < w <= 10000 for w in self.weights):
            raise ValueError("vehicle.weights")
        if any(not 0 < s <= 50 for s in self.spacings):
            raise ValueError("vehicle.spacings")
        return self


class Pedestrian(InputModel):
    """S6-25 pedestrian load on a sidewalk (3.8.9), v0.9.96, formula v0.9.97.

    p = 4.25 (0.5 + √(5 / s)) kPa, at most 4.25 kPa, with s (m) the total
    loaded length (sum of the loaded spans). The load per girder is p times
    the tributary width. No dynamic allowance, no FT, no axle factor. With
    ``maintenance`` the envelope also covers the maintenance vehicle
    (3.8.11), never concomitant with the pedestrians.
    """

    width_source: Literal["slab", "manual"] = "slab"
    width: float = Field(default=2000, gt=0, le=30000)  # tributary width, mm
    maintenance: bool = False


class ThermalLoad(InputModel):
    """Imposed deformations (v0.9.7), each analysed on its own.

    ``imposed`` selects the case: thermal gradient, slab shrinkage or slab
    creep. Shrinkage and creep are a uniform shortening of the slab concrete,
    restrained by the girder on the long-term composite section (k·n).
    """

    imposed: Literal["thermal", "shrinkage", "creep"] = "thermal"
    shrinkage_micro: float = Field(default=250, ge=0, le=3000)  # slab shortening, 10^-6
    creep_phi: float = Field(default=2.0, ge=0, le=10)  # creep coefficient
    creep_stress: float = Field(
        default=3.0, ge=0, le=60
    )  # sustained slab compression, MPa
    modular_factor: float = Field(default=3.0, ge=1, le=10)  # k of the k·n section
    delta_T: float = Field(default=15, ge=-100, le=100)  # T_top - T_bottom, deg C
    alpha_micro: float = Field(default=12, gt=0, le=100)  # 10^-6 / deg C
    # v0.9.6: the reference depth comes from the sections (girder + haunch +
    # slab when a slab is defined); "manual" keeps the depth below (direct-EI
    # sections, projects saved before v0.9.6).
    depth_source: Literal["sections", "manual"] = "sections"
    depth: float = Field(default=1200, gt=0, le=15000)  # manual reference depth, mm
    # Linear through the depth, or bilinear (S6-25 type, composite deck):
    # slab_delta_T from the top of the slab to its bottom, constant below.
    profile: Literal["linear", "bilinear"] = "linear"
    slab_delta_T: float = Field(default=30, ge=-100, le=100)


class Distribution(InputModel):
    """S6-25 truck load fraction FT, slab-on-girder bridge (classes A and B).

    With ``apply``, the live-load effects (trucks and lane load, ML and VL) are
    multiplied station by station by the moment fraction (M and δ) and the
    shear fraction (V) of their zone (M+ span zones and M− support zones of
    Figure 5.1), for the selected girder and limit state. Reactions keep one
    full lane. For an exterior girder the dead-load shear takes Fs.
    """

    enabled: bool = False
    apply: bool = False
    # Slab and voided-slab bridges (5.6.4.2, 5.6.5): effects per metre of width.
    bridge_type: Literal[
        "slab_on_girder",
        "slab",
        "voided_slab",
        # v1.01: decks on steel girders (5.6.7, A5.3.4).
        "steel_grid",
        "aluminum",
        "wood_laminated",
        "wood_plank",
    ] = "slab_on_girder"
    # v1.01: steel grid thickness (< 100 mm or not) and transversely laminated
    # wood thickness (interpolated between 140 and 290 mm), mm.
    deck_thickness: float = Field(default=150.0, ge=10, le=600)
    # v1.01: lever rule for the exterior-girder shear of these decks: distance
    # from the curb or barrier face to the outer wheel line, m.
    wheel_edge: float = Field(default=0.6, ge=0, le=3)
    slab_width: float = Field(default=12.0, gt=1, le=60)  # B, m (slab bridges)
    # Be, m: equivalent width of a slab with tapered free edges (5.5.2); B if None.
    equivalent_width: float | None = Field(default=None, gt=1, le=60)
    girders: int = Field(default=5, ge=1, le=40)  # N
    spacing: float = Field(default=3.11, gt=0.3, le=10)  # S, m
    overhang: float = Field(default=1.555, ge=0, le=6)  # Sc, m
    carriageway: float = Field(default=10.4, gt=1, le=60)  # Wc, m
    road_class: Literal["AB", "CD"] = "AB"  # Table 5.3 / Table A5.3.3
    skew: float = Field(default=8.5, ge=0, le=45)  # ψ, degrees
    h_left: float = Field(default=3.0, ge=0, le=30)  # integral abutment height, m
    h_right: float = Field(default=3.0, ge=0, le=30)
    girder: Literal["interior", "exterior"] = "interior"
    state: Literal["ULS", "FLS"] = "ULS"
    # Skew factor Fs on the permanent-load shear and reactions of the
    # exterior girder / exterior slab portion (5.6.6.2), when FT is applied.
    fs_dead: bool = True


V0997_RESISTANCE = (
    "mode",
    "section",
    "fy_bar",
    "phi_s",
    "phi_r",
    "phi_c",
    "mf_pos",
    "mf_neg",
    "mf_neg_steel",
    "vf",
)


class Resistance(InputModel):
    """Factored resistance of the steel girders (S6-25 Section 10), v0.9.98.

    Display only: it never changes the analysis. The resistance is computed
    at every station with the section in force there and compared with the
    factored effects of the analysis (permanent + live loads as computed).
    ``enabled`` draws Mr and Vr around the V and M envelopes. ``types`` gives
    per section index how a steel girder resists: "composite" (with the slab
    of its section properties) or "steel" (girder alone); a missing entry
    means composite when the section has a slab, else steel alone. The
    resistance factors are those of S6-25 (φs 0.95, φr 0.90, φc 0.75).
    Lengths in mm.
    """

    enabled: bool = False
    types: list[Literal["composite", "steel"]] = Field(
        default_factory=list, max_length=20
    )
    stiffened: bool = True
    stiffener_spacing: float = Field(default=3000, gt=0, le=100000)  # a, mm
    # Unbraced length L of the compression flange (10.10.2.3, 10.10.3.3):
    # girder alone in M+ and M−, bottom flange of composite M− (v0.9.99:
    # classes 1-2 too).
    unbraced_length: float = Field(default=6000, gt=0, le=200000)
    # v0.9.99: effects compared with the resistance: permanent loads only,
    # live load only, or both (as analysed). ``enabled`` (Mr/Vr drawn on the
    # main diagrams in v0.9.98) is kept for old files and no longer used.
    effects: Literal["both", "dead", "live"] = "both"

    @model_validator(mode="before")
    @classmethod
    def drop_v0997_inputs(cls, data):
        # v0.9.97 entered Mf, Vf, the φ factors and the bar fy here.
        if isinstance(data, dict):
            data = {k: v for k, v in data.items() if k not in V0997_RESISTANCE}
        return data

    def type_of(self, index: int, section: "Section") -> str:
        """Resistance type of section ``index``: steel alone without a slab."""
        slab = section.composite is not None and section.composite.enabled
        kind = self.types[index] if 0 <= index < len(self.types) else None
        if not slab:
            return "steel"
        return kind or "composite"


class DeckJoint(InputModel):
    """Deck joint at any station (v0.9.99): launching or demolition stages.

    ``hinge``: moment release, the shear is transmitted. ``cut``: the deck is
    sawn through, neither shear nor moment crosses the joint; each part must
    be stable on its own supports. ``keep`` (cut only): both parts, or only
    the part left or right of the cut (the other one is removed: no
    stiffness, no load, no reaction). ``x`` in m from the left end.
    """

    enabled: bool = False
    x: float = Field(default=10.0, gt=0, le=1400)
    kind: Literal["hinge", "cut"] = "cut"
    keep: Literal["both", "left", "right"] = "both"


class ModalSettings(InputModel):
    """Free-vibration settings. The mass is not a load: it only feeds the
    eigenvalue analysis and never changes the static results."""

    mass_source: Literal["dead", "custom"] = "dead"
    mass: float = Field(default=10.0, gt=0, le=10000)  # kN/m (weight), custom source
    modes: int = Field(default=6, ge=1, le=12)


class Model(InputModel):
    spans: list[Span] = Field(
        default_factory=lambda: [Span(), Span()], min_length=1, max_length=7
    )
    # "split" (v0.9.8): pier with two bearing lines and a deck joint. The
    # deck is discontinuous there; each side has its own reaction.
    supports: list[Literal["pin", "roller", "fixed", "spring", "split"]] = Field(
        default_factory=lambda: ["roller", "pin", "roller"]
    )
    # Rotational spring stiffness per support, kN·m/rad (used by "spring").
    support_springs: list[float] = Field(default_factory=list, max_length=8)
    sections: list[Section] = Field(
        default_factory=lambda: [Section()], min_length=1, max_length=20
    )
    nonprismatic: bool = False
    dead: list[DeadLoad] = Field(default_factory=lambda: [DeadLoad()], max_length=30)
    self_weight: SelfWeight = Field(default_factory=SelfWeight)
    live: LiveLoad = Field(default_factory=LiveLoad)
    pedestrian: Pedestrian = Field(default_factory=Pedestrian)
    thermal: ThermalLoad = Field(default_factory=ThermalLoad)
    modal: ModalSettings = Field(default_factory=ModalSettings)
    resistance: Resistance = Field(default_factory=Resistance)
    joint: DeckJoint = Field(default_factory=DeckJoint)
    distribution: Distribution = Field(default_factory=Distribution)
    load_mode: Literal["dead", "live", "both", "thermal"] = "both"
    subdivisions: int = Field(default=10, ge=2, le=100)
    # Legacy (<= 0.9.99): the mesh is now chosen from the geometry (engine.mesh).
    precision: Literal["auto", "standard", "fine"] = "auto"

    @model_validator(mode="after")
    def consistency(self):
        if len(self.supports) != len(self.spans) + 1:
            raise ValueError("model.supports")
        if self.supports[0] == "split" or self.supports[-1] == "split":
            raise ValueError("model.split_end")  # interior supports only
        if self.nonprismatic and any(s.kind == "nebt" for s in self.sections):
            # v0.9.6: precast NEBT girders have a constant tabulated section.
            raise ValueError("model.nebt_nonprismatic")
        if "spring" in self.supports:
            # One rotational stiffness per support (kN m/rad); only the
            # "spring" entries are used, the others are ignored.
            if len(self.support_springs) != len(self.supports):
                raise ValueError("model.support_springs")
            if any(
                not 0 < k <= 1e13
                for k, s in zip(self.support_springs, self.supports)
                if s == "spring"
            ):
                raise ValueError("model.support_springs")
        for span in self.spans:
            if span.section >= len(self.sections):
                raise ValueError("model.section")
            previous = 0
            for zone in span.zones:
                if zone.end <= previous or zone.section >= len(self.sections):
                    raise ValueError("model.zones")
                if zone.end_section is not None and zone.end_section >= len(
                    self.sections
                ):
                    raise ValueError("model.section")
                if zone.profile != "constant" and any(
                    self.sections[i].kind in ("ei", "nebt")
                    for i in (
                        zone.section,
                        zone.end_section
                        if zone.end_section is not None
                        else zone.section,
                    )
                ):
                    raise ValueError("model.constant_ei_zone")
                if zone.profile != "constant":
                    a = self.sections[zone.section]
                    b = self.sections[
                        zone.end_section
                        if zone.end_section is not None
                        else zone.section
                    ]
                    p = plate_source(zone, a, b)
                    if min(a.depth, b.depth) <= p.top_thickness + p.bottom_thickness:
                        raise ValueError("geometry.depth")
                previous = zone.end
            if self.nonprismatic and span.zones and abs(previous - 1) > 1e-9:
                raise ValueError("model.coverage")
        if any(load.span >= len(self.spans) for load in self.dead):
            raise ValueError("load.span")
        if self.joint.enabled:
            # Strictly inside a span, at least 5 cm from any support.
            ends = [0.0]
            for span in self.spans:
                ends.append(ends[-1] + span.length)
            if not 0 < self.joint.x < ends[-1] or any(
                abs(self.joint.x - e) < 0.05 for e in ends
            ):
                raise ValueError("joint.position")
        return self


def default_model() -> Model:
    """Starting model of the application (v0.9.2).

    Non-prismatic girder: S2 (deeper) only over the interior supports, reached
    by parabolic depth haunches over 20 % of each adjacent span, plates, E and
    M from the deeper section; S1 elsewhere, including at the abutments. The
    S6-25 truck load fraction is applied (interior girder, ULS).
    """
    model = Model(
        nonprismatic=True,
        sections=[Section(), Section(name="S2", depth=1560)],
    )
    apply_default_haunches(model)
    return Model.model_validate(model.model_dump())


def apply_default_haunches(model: Model, deep: int = 1, length: float = 0.2):
    """Parabolic haunches to section ``deep`` at every interior support only."""
    n = len(model.spans)
    for i, span in enumerate(model.spans):
        shallow = span.section if span.section != deep else 0
        zones = []
        if i > 0:
            zones.append(
                Zone(
                    end=length,
                    section=deep,
                    end_section=shallow,
                    profile="parabolic",
                    plates="deep",
                )
            )
        if i < n - 1:
            zones.append(Zone(end=1 - length, section=shallow))
            zones.append(
                Zone(
                    end=1,
                    section=shallow,
                    end_section=deep,
                    profile="parabolic",
                    plates="deep",
                )
            )
        else:
            zones.append(Zone(end=1, section=shallow))
        span.zones = zones
    return model
