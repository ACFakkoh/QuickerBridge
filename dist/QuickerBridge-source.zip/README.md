# QuickerBridge 0.4

**Anthony Chéruel · 2026-09-12 · Français / English**

Un outil de calcul préliminaire de poutres continues de ponts, avec PyCBA dans le
navigateur. Géométrie, charges et diagrammes restent réunis dans une interface
compacte. Aucune installation de Python et aucun serveur local pour les utilisateurs.

## Démarrer

- **Sur le web :** ouvrez le lien GitHub Pages fourni par l’auteur.
- **Fichier reçu :** ouvrez `QuickerBridge.html` dans un navigateur moderne. Si vous
  recevez l’archive portable, extrayez-la avant d’ouvrir le HTML.
- Une connexion Internet est nécessaire au démarrage pour charger Pyodide et ses
  bibliothèques. Le cache peut accélérer les ouvertures suivantes; cette édition
  ne garantit pas un fonctionnement hors connexion.
- FR est la langue initiale. Le bouton EN/FR en haut mémorise ensuite votre choix.

Les calculs s’exécutent dans un processus de travail du navigateur. Les données du
pont ne sont pas envoyées à un serveur de calcul. Fermer l’onglet interrompt le calcul.

## Saisir un modèle

1. **Géométrie :** choisissez 1 à 5 travées, leurs longueurs en mètres et les appuis.
   Les appuis articulés et à rouleaux bloquent le déplacement vertical, avec
   continuité de la poutre aux appuis intérieurs.
2. **Sections :** saisissez les dimensions des tôles en mm et E en GPa, ou une
   rigidité EI constante directement en kN·m². La hauteur comprend les semelles.
3. **Charges :** choisissez permanentes, routières, les deux, ou thermique seul.
   Plusieurs charges uniformes sont possibles. CL-750QC à 80 % est le choix initial;
   CL-625, le camion et le tandem AASHTO HL-93, le train Cooper E et un véhicule
   personnalisé de 1 à 7 essieux sont disponibles.
4. Attendez la fin du calcul, puis inspectez les diagrammes et le tableau.
   L’augmentation du nombre de stations du tableau ne raffine pas le solveur.

Le modèle initial comporte **2 × 34,8 m**, une poutre de **1200 mm** de hauteur,
une semelle supérieure **350 × 25 mm**, une âme de **14 mm** et une semelle
inférieure **600 × 50 mm**. E = 200 GPa; multiplicateur d’inertie M = 1.
Ces valeurs sont des données de départ, pas une validation de ce pont.

### Rigidité et zones non prismatiques

Le multiplicateur d’inertie M agit sur **EI = E × I acier × M**. M = 4 quadruple
la rigidité. L’inertie affichée reste celle de l’acier brut; EI inclut M. Ce moyen
permet une hypothèse de rigidité effective, sans calculer une dalle transformée,
son centre de gravité, les contraintes ou la résistance composite.

Les zones se suivent de 0 à 100 % de chaque travée. La section initiale d’une zone
fournit ses tôles, E, M et sa hauteur initiale. La section finale fournit **seulement
la hauteur cible**. La hauteur peut être constante, linéaire ou parabolique.
Les semelles et l’épaisseur de l’âme restent constantes dans la zone; pour les
changer, commencez une nouvelle zone. Le profil parabolique est tangent au côté
le moins haut. [Détails et comparaison avec CSiBridge](NONPRISMATIC.md).

### Enveloppes et thermique

Les deux lignes épaisses limitent les enveloppes min/max. Chaque extrême peut
venir d’une disposition de charges différente. Cliquez sur un extrême pour voir
la disposition compatible. Les flèches d’essieux et leurs nombres montrent les
**charges nominales**; dans un cas de voie canadien, elles montrent seulement les
charges réduites. Elles n’affichent jamais le CMD, même lorsque le calcul l’applique.
Moment positif en travée, flèche positive vers le bas,
réactions positives vers le haut.

Le mode thermique applique seul un gradient linéaire : ΔT = Tdessus − Tdessous.
Saisissez α en 10⁻⁶/°C et une hauteur thermique de référence en mm. Cette hauteur
est indépendante de la géométrie des sections. Le même gradient et la même
courbure libre sont appliqués à toutes les travées. Un dessus plus chaud courbe
la poutre vers le haut. Le cas thermique ne se superpose pas aux autres charges.

### Enregistrer, rouvrir et exporter

**Enregistrer** télécharge un fichier `.quickerbridge.json` avec les paramètres.
**Ouvrir** vérifie le fichier et recalcule les résultats. Aucun diagramme ni résultat
n’est sauvegardé dans le projet. Enregistrez avant de fermer le navigateur.
Les anciens projets dont les tôles variaient continûment doivent être consultés
avec v0.3 puis redéfinis explicitement en zones dans v0.4; l’application les signale.

**Excel** exporte les enveloppes, les réactions et le modèle, même si une position
particulière du camion est affichée. En mode thermique, il exporte ce cas unique.
Les appuis partagés ont deux lignes pour les cisaillements gauche et droite.

### Si le calcul paraît lent

Le premier démarrage télécharge le moteur. Ensuite, modifier la géométrie ou EI
reconstruit les fonctions d’influence; modifier uniquement les charges peut les
réutiliser. Les zones nombreuses, cinq travées et le mode Fin prennent plus de temps.
Les calculs non prismatiques de v0.4 évitent de recalculer inutilement la rigidité.
Si le moteur ne démarre pas, vérifiez la connexion et rechargez la page. Si une
entrée est invalide, corrigez-la avant d’utiliser les résultats grisés.

## English quick guide

Open the provided GitHub Pages link, or double-click the extracted
`QuickerBridge.html`. **No Python installation or local server is needed.** Internet
access is required to download the browser runtime; guaranteed offline use is not
included. Calculations run locally in your browser. Use the top EN/FR toggle.

Define 1–5 spans, supports, steel plates or direct constant EI, then select dead,
live, combined, or thermal-only loading. An inertia modifier multiplies the gross
steel I for stiffness only; it does not calculate composite section properties.
In a non-prismatic zone, only height varies. Start-section plates, E and modifier
stay fixed until the next zone; the end section supplies only its target height.
See [depth versus EI interpolation](NONPRISMATIC.md).

Both envelope limits are drawn in bold. Click an extreme to inspect its governing
arrangement. Axle arrows show nominal loads, or Canadian lane-reduced loads in a
lane case; they never show dynamic allowance. The solver applies the selected code
factors. Save/Open exchanges model-only `.quickerbridge.json` files. Excel exports
the envelope, or the single thermal case. Shared supports retain both shear limits.

## Portée / Scope

PyCBA solves a linear elastic, 1-D Euler–Bernoulli continuous beam. One lane uses
the selected standard vehicle. CAN/CSA S6-25 §3.8.4.5.3 dynamic allowance is applied
to Canadian truck axle subsets; reduced-truck-plus-lane cases have no dynamic
allowance. HL-93 envelopes its permitted 4.3–9.0 m rear-axle spacing and applies
its 33% allowance to truck/tandem axles only, with a 9.3 kN/m companion UDL. Cooper
uses PyCBA’s full E-series train and companion UDL. Truck and lane cases are
alternatives. No automatic self-weight, load combinations, transverse
load distribution, shear deformation, staged construction, prestress, cracking,
resistance checks or code compliance verification is included. Numerical envelopes
are sampled; compare Standard and Fine when assessing sensitivity.

**Valeurs préliminaires indicatives seulement — ne remplacent pas une conception détaillée.**

**Indicative preliminary values only — not a substitute for detailed design.**

Utilisation et responsabilité : bien que je considère ces outils exempts d’erreurs,
je ne peux être tenu responsable de leurs résultats. Ils sont destinés à
l’apprentissage et ne doivent pas servir à concevoir un pont.

Use and liability: While I believe these tools to be free of error, I cannot be held
liable for their results. They are to be used for instruction and should not be used
to design a bridge.

## Développement et publication

Pour installer les sources, tester, reconstruire les livrables ou publier sur
GitHub Pages, consultez [le guide développeur](README_DEVELOPER.md).
[Validation](VALIDATION.md) · [Notices des composants tiers](THIRD_PARTY_NOTICES.md).
